package taskService;

import java.util.ArrayList;

import taskService.Task;

public class TaskService {

	public static ArrayList<Task> TaskList = new ArrayList<>();
	
	public static void addTask(String ID, String name, String desc) {
		Task task = new Task(ID, name, desc);
		
		TaskList.add(task);
	}
	
	public static void removeTask(String ID) {
		for (int i = 0; i < TaskList.size(); i++) {
			if (TaskList.get(i).getID() == ID) {
				TaskList.remove(i);
			}
		}
	}
	
	public static void updateTask(String ID, boolean field, String newValue) {
		for (int i = 0; i < TaskList.size(); i++) {
			if (TaskList.get(i).getID() == ID) {
				if (field) {
					TaskList.get(i).setName(newValue);
				}
				else {
					TaskList.get(i).setDescription(newValue);
				}
			}
		}
	}
}
