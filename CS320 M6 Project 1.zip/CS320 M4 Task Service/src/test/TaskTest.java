package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import taskService.Task;

class TaskTest {

	@Test
	void testTaskIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task ("12345678901", "Clean stuff", "clean XYZ");
		});   	}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task ("1234567890", "Clean stuff2345678901", "clean XYZ");
		});   	}
	
	@Test
	void testTaskDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task ("1234567890", "Clean stuff", "clean XYZ000000000000000000000000000000000000000000");
		});   	}
}
