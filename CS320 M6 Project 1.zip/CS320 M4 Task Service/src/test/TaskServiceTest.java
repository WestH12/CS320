package test;

import static org.junit.jupiter.api.Assertions.*;
import taskService.Task;
import org.junit.jupiter.api.Test;
import taskService.TaskService;

class TaskServiceTest {

	@Test
	void testAddTask() {
		int size = TaskService.TaskList.size();
		TaskService.addTask("12345", "Clean Stuff", "Clean XYZ");
		assertTrue(size < TaskService.TaskList.size()); //Checking to see that Taskist grew in size
		for (int i = 0; i < TaskService.TaskList.size(); i++) {
			Task curr = TaskService.TaskList.get(i);
			if (curr.getID() == "12345") {
				assertTrue(curr.getID().equals("12345"));
				assertTrue(curr.getName().equals("Clean Stuff"));
				assertTrue(curr.getDescription().equals("Clean XYZ"));
			}
		}
		
	}

	@Test
	void testRemoveTask() {
		TaskService.TaskList.clear();
		TaskService.addTask("12345", "Clean Stuff", "Clean XYZ");
		TaskService.addTask("123456", "Clean Bathroom", "Clean HJK");
		TaskService.addTask("1234567", "Clean Bedroom", "Clean DFG");
		int size = TaskService.TaskList.size();
		TaskService.removeTask("12345");
		assertTrue(size > TaskService.TaskList.size());
		for (int i = 0; i < TaskService.TaskList.size(); i++) {
			if (TaskService.TaskList.get(i).getID() == "12345") {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}
	
	@Test
	void testUpdateName() {
		TaskService.TaskList.clear();
		TaskService.addTask("12345", "Clean Stuff", "Clean XYZ");
		
		TaskService.updateTask("12345", true, "Clean Everything");
		for (int i = 0; i < TaskService.TaskList.size(); i++) {
			Task curr = TaskService.TaskList.get(i);
			if (curr.getID() == "12345") {
				assertTrue(curr.getName().equals("Clean Everything"));
			}
		}
	}
	
	@Test
	void testUpdateDescription() {
		TaskService.TaskList.clear();
		TaskService.addTask("12345", "Clean Stuff", "Clean XYZ");
		
		TaskService.updateTask("12345", false, "Clean ZYX");
		for (int i = 0; i < TaskService.TaskList.size(); i++) {
			Task curr = TaskService.TaskList.get(i);
			if (curr.getID() == "12345") {
				assertTrue(curr.getDescription().equals("Clean ZYX"));
			}
		}
	}
	
}
