package appointmentService;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {

	public static ArrayList<Appointment> AppointmentList = new ArrayList<>();
	
	public static void addAppointment(String ID, Date date, String description) {
		Appointment appt = new Appointment(ID, date, description);
		AppointmentList.add(appt);
	}
	
	public static void removeAppointment(String ID) {
		for (int i = 0; i < AppointmentList.size(); i++) {
			if (AppointmentList.get(i).getID() == ID) {
				AppointmentList.remove(i);
			}
		}
	}
	
	public static void updateAppointmentDate(String ID, Date newDate) {
		for (int i = 0; i < AppointmentList.size(); i++) {
			if (AppointmentList.get(i).getID() == ID) {
				AppointmentList.get(i).setDate(newDate);
			}
		}
	}
	
	public static void updateAppointmentDescription(String ID, String newDesc) {
		for (int i = 0; i < AppointmentList.size(); i++) {
			if (AppointmentList.get(i).getID() == ID) {
				AppointmentList.get(i).setDescription(newDesc);
			}
		}
	}
	
}
