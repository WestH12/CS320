package test;

import java.util.Date;
import appointmentService.AppointmentService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import appointmentService.Appointment;

public class AppointmentTest {
	
	//Below two variables are used to ensure that time is two hours ahead of current time
	Date curr = new Date();
	long timeAddition = 2 * 60 * 60 * 1000;
	
	@Test
	void testApptIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("12345678901", new Date(curr.getTime() + timeAddition), "Go to the XYZ");
		});		}
	
	@Test
	void testApptIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(null, new Date(curr.getTime() + timeAddition), "Go to the XYZ");
		});		}
	
	@Test
	void testApptIDNotUnique() {
		AppointmentService.AppointmentList.clear();
		AppointmentService.addAppointment("1234", new Date(curr.getTime() + timeAddition), "Go to the ZYX");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("1234", new Date(curr.getTime() + timeAddition), "Go to the XYZ");
		});		}
	
	@Test
	void testApptDateInThePast() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> { //Subtract timeAddition to place the date in the past
			Appointment appointment = new Appointment("1234567890", new Date(curr.getTime() - timeAddition), "Go to the XYZ");
		});		}
	
	@Test
	void testApptDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("1234567890", null, "Go to the XYZ");
		});		}
	
	@Test
	void testApptDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("1234567890", new Date(curr.getTime() + timeAddition), "Go to the XYZ00000000000000000000000000000000000000");
		});		}
	
	@Test
	void testApptDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment("1234567890", new Date(curr.getTime() + timeAddition), null);
		});		}
}
