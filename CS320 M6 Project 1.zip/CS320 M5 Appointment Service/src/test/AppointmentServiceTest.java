package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;

import org.junit.jupiter.api.Test;

import appointmentService.Appointment;
import appointmentService.AppointmentService;


public class AppointmentServiceTest {
	//Below two variables are used to ensure that time is two hours ahead or behind current time
		Date curr = new Date();
		long timeAddition = 2 * 60 * 60 * 1000;
		Date timeVal = new Date(curr.getTime() + timeAddition); //Created to ensure that the time matches exactly and processing time does influence testing

	@Test
	void testAddAppointment() {
		AppointmentService.AppointmentList.clear();
		int size = AppointmentService.AppointmentList.size();
		AppointmentService.addAppointment("12345", timeVal, "Go to XYZ");
		assertTrue(size < AppointmentService.AppointmentList.size());
		for (int i = 0; i < AppointmentService.AppointmentList.size(); i++) {
			Appointment curr = AppointmentService.AppointmentList.get(i);
			if (curr.getID() == "12345") {
				assertTrue(curr.getID().equals("12345"));
				assertTrue(curr.getDate().equals(timeVal));
				assertTrue(curr.getDescription().equals("Go to XYZ"));
			}
		}
	}
	
	@Test 
	void testRemoveAppointment() {
		AppointmentService.AppointmentList.clear();
		AppointmentService.addAppointment("12345", timeVal, "Go to XYZ");
		int size = AppointmentService.AppointmentList.size();
		AppointmentService.removeAppointment("12345");
		assertTrue(size > AppointmentService.AppointmentList.size());
		for (int i = 0; i < AppointmentService.AppointmentList.size(); i++) {
			if (AppointmentService.AppointmentList.get(i).getID() == "12345") {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}
	
	@Test
	void testUpdateAppointmentDate() {
		long addition = 2 * 1000;
		Date newTimeVal = new Date(curr.getTime() + timeAddition + addition);
		AppointmentService.AppointmentList.clear();
		AppointmentService.addAppointment("12345", timeVal, "Go to XYZ");
		AppointmentService.updateAppointmentDate("12345", newTimeVal);
		for (int i = 0; i < AppointmentService.AppointmentList.size(); i++) {
			if (AppointmentService.AppointmentList.get(i).getID() == "12345") {
				assertTrue(AppointmentService.AppointmentList.get(i).getDate().equals(newTimeVal));
			}
		}
	}
	
	@Test
	void testUpdateAppointmentDesc() {
		AppointmentService.AppointmentList.clear();
		AppointmentService.addAppointment("12345", timeVal, "Go to XYZ");
		AppointmentService.updateAppointmentDescription("12345", "Go to ZYX");
		for (int i = 0; i < AppointmentService.AppointmentList.size(); i++) {
			if (AppointmentService.AppointmentList.get(i).getID() == "12345") {
				assertTrue(AppointmentService.AppointmentList.get(i).getDescription().equals("Go to ZYX"));
			}
		}
	}
}
