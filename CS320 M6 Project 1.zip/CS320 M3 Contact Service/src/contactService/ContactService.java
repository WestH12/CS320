package contactService;

public class ContactService {
	public static void deleteContact(String ID) {
		for (int i = 0; i < Contact.ContactList.size(); i++) {
			Contact curr = Contact.ContactList.get(i);
			if (ID == curr.getID()) {
				Contact.ContactList.remove(i);
			}
		}
	}

	public static void addContact(String ID, String firstName, String lastName, String phone, String address) {

		Contact newContact = new Contact(ID, firstName, lastName, phone, address);
	}

	public static void updateContact(String ID, int field, String newValue) {
		for (int i = 0; i < Contact.ContactList.size(); i++) {
			Contact curr = Contact.ContactList.get(i);
			if (ID == curr.getID()) {
				switch (field) {
				case 1:
					curr.setFirstName(newValue);
					break;
				case 2:
					curr.setLastName(newValue);
					break;
				case 3:
					curr.setPhone(newValue);
					break;
				case 4:
					curr.setAddress(newValue);
					break;
				}
			}
		}
	}
}
