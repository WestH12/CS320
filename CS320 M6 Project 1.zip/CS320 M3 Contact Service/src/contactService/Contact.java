package contactService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Contact {
	private String ID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getID() {
		return ID;
	}


	public static ArrayList<Contact> ContactList = new ArrayList<>();
	
	public static void printContactList() {
		for (int i = 0; i < ContactList.size(); i++) {
			Contact curr = ContactList.get(i);
			printContact(curr);
		}
	}

	
	public Contact(String ID, String firstName, String lastName, String phone, String address) {
		if (ID == null || ID.length()>10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		if (firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Invalid first name");
		}
		if (lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Invalid last name");
		}
		if (phone == null || phone.length()!=10) {
			throw new IllegalArgumentException("Invalid phone");
		}
		if (address == null || address.length()>30) {
			throw new IllegalArgumentException("Invalid address");
		}
		this.ID = ID;
		this.firstName = firstName;
		this.lastName =lastName;
		this.phone = phone;
		this.address = address;
		ContactList.add(this); 
	}
	
	public static void printContact(Contact c) {
		System.out.println("ID: " + c.ID + " | First Name: " + c.firstName + " | Last Name: " + c.lastName + " | Phone: " + c.phone + " | Address: " + c.address);
	}
	
	
	public static void main(String[] args) {
		Contact w = new Contact("1", "W", "H", "12", "25");
		Contact z = new Contact("2", "W", "H", "12", "25");
		printContactList();

	}

}
