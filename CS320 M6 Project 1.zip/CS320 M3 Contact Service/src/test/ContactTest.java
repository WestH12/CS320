package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contactService.Contact;

class ContactTest {

	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact ("12345678901", "W", "H", "1234567890", "25");
		});   	}

	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact ("123456789", "Westley8901", "Hunter", "1234567890", "25");
		});   	}
	
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact ("123456789", "Westley", "Hunter78901", "1234567890", "25");
		});   	}
	
	@Test
	void testContactPhoneShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact ("123456789", "Westley", "Hunter", "123456789", "25");
		});   	}
	
	@Test
	void testContactPhoneLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact ("123456789", "Westley", "Hunter", "123456789012", "25");
		});   	}
	
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact ("123456789", "Westley", "Hunter", "1234567890", "2500000000000000000000000000000");
		});   	}
	
	
	
}
