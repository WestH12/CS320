package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import contactService.Contact;
import contactService.ContactService;

class ContactServiceTest {

	@Test
	void testAddContact() {
		int size = Contact.ContactList.size();
		
		ContactService.addContact("12345", "Westley", "Hunter", "1234567890", "2500 Address lane");
		assertTrue(size < Contact.ContactList.size()); //Checking to see that ContactList grew in size
		for (int i = 0; i < Contact.ContactList.size(); i++) {
			Contact curr = Contact.ContactList.get(i);
			if (curr.getID() == "12345") {
				assertTrue(curr.getID().equals("12345"));
				assertTrue(curr.getFirstName().equals("Westley"));
				assertTrue(curr.getLastName().equals("Hunter"));
				assertTrue(curr.getPhone().equals("1234567890"));
				assertTrue(curr.getAddress().equals("2500 Address lane"));
			}
		}
	}

	
	@Test
	void testDeleteContact() {
		Contact contact1 = new Contact ("12345", "Westley", "Hunter", "1234567890", "2500 Address lane");
		Contact contact2 = new Contact ("123456", "Wesey", "Huter", "1234567980", "2500 Address ct");
		Contact contact3 = new Contact ("1234567", "Wesley", "Huner", "1234567890", "2500 Address lane");
		int size = Contact.ContactList.size();
		ContactService.deleteContact("123456");
		assertTrue(size > Contact.ContactList.size()); //Checking to see of ContactList shrunk in size
		for (int i = 0; i < Contact.ContactList.size(); i++) {
			Contact curr = Contact.ContactList.get(i);
			if (curr.getID() == "123456") {
				assertTrue(false);
			}
		}
		assertTrue(true);
	}
	
	@Test
	void testUpdateFirstName() {
		Contact contact = new Contact ("123456", "Westley", "Hunter", "1234567890", "2500 Address lane");
		ContactService.updateContact("123456", 1, "Percy");
		assertTrue(contact.getFirstName().equals("Percy"));
	}
	
	@Test
	void testUpdateLastName() {
		Contact contact = new Contact ("123456", "Westley", "Hunter", "1234567890", "2500 Address lane");
		ContactService.updateContact("123456", 2, "Jackson");
		assertTrue(contact.getLastName().equals("Jackson"));
	}
	
	@Test
	void testUpdatePhone() {
		Contact contact = new Contact ("123456", "Westley", "Hunter", "1234567890", "2500 Address lane");
		ContactService.updateContact("123456", 3, "0987654321");
		assertTrue(contact.getPhone().equals("0987654321"));
	}
	
	@Test
	void testUpdatePAddress() {
		Contact contact = new Contact ("123456", "Westley", "Hunter", "1234567890", "2500 Address lane");
		ContactService.updateContact("123456", 4, "1122 Driving Lane");
		assertTrue(contact.getAddress().equals("1122 Driving Lane"));
	}
	
}
